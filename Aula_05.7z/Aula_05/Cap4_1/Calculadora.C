/* Calculadora.C */
/*Simula uma calculadora de 4 opera��es*/
#include <stdio.h>
#include <stdlib.h>
	
int main()		
{
	const int TRUE=1;

	while(TRUE)	/* Sempre verdadeiro*/
	{
		float n1,n2;
		char op;

		printf("\nDigite n�mero operador n�mero: ");
		scanf("%f%c%f", &n1, &op, &n2);

		if( op == '+')
			printf("\n%f", n1 + n2);
		else
			if( op == '-')
				printf("\n%f", n1 - n2);
			else
				if( op == '*')
					printf("\n%f", n1 * n2);
				else
					if( op == '/')
						printf("\n%f", n1 / n2);
					else 
						printf("\nOperador desconhecido.");
	}
	printf("\n");
	system("PAUSE");	
	return 0;			
}
