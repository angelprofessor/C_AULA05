/* Contachar.C */
/* Conta caracteres de uma frase */
#include <stdio.h>
#include <stdlib.h>
#include <conio.h> /* para getche() */
int main()				
{	
	int cont=0; /* Contador */

	while(getche() != '\r') /* Enquanto n�o [Enter]  */
		cont++; /* Corpo do la�o */
	/* Fora do la�o */
	printf("\nO n�mero de caracteres � %d\n" , cont);

	system("PAUSE");	
	return 0;		
}
